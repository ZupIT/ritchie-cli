# Generate compose

## Command

```bash
rit docker generate compose
```

## Description

Generate docker-compose.yml in current directory.
