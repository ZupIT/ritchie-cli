---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE]"
labels: feature
assignees: ''

---

<!-- Please only use this template for submitting
new feature or enhancement requests -->

**What would you like to be added**:

**Why is this needed**:
