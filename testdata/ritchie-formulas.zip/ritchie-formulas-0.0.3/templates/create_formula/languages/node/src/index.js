const run = require("./hello/hello")

const INPUT1 = process.env.SAMPLE_TEXT
const INPUT2 = process.env.SAMPLE_LIST
const INPUT3 = process.env.SAMPLE_BOOL

run(INPUT1, INPUT2, INPUT3)
