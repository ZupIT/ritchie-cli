#!/bin/sh
runFormula() {
  echo "Hello World! "
  echo "You receive $SAMPLE_TEXT in text. "
  echo "You receive $SAMPLE_LIST in list. "
  echo "You receive $SAMPLE_BOOL in boolean. "
}
