#!/usr/bin/python3


def Run(input1, input2, input3):
    print("Hello World!")
    print("You receive {} in text.".format(input1))
    print("You receive {} in list.".format(input2))
    print("You receive {} in boolean.".format(input3))
