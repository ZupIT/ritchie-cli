<?php
	function Run($input1, $input2, $input3) {
		echo "Hello World! \n";
		echo "You receive $input1 in text. \n";
		echo "You receive $input2 in list. \n";
		echo "You receive $input3 in boolean. \n";
	}
?>
