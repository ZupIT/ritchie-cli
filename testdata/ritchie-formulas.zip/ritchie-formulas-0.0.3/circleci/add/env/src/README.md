# CircleCI add env

## command

```bash
rit circleci add env
```

## description

This formula receives 5 inputs (token, repo owner, repo name, env name, env value)
and adds a new env to circle ci project.
