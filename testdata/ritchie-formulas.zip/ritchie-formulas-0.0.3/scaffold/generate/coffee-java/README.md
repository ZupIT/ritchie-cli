# coffee-java

## command

```bash
rit scaffold generate coffee-java
```

## description

This is a formula receive 4 inputs (customer name, coffee type, delivery,
no delay) and builds a coffee.
