# coffee-node

## command

```bash
rit scaffold generate coffee-node
```

## local test

```bash
make test-local form=SC_COFFEE_NODE
```

## description

This is formula receive 4 inputs (customer name, coffee type, delivery,
no delay) and builds a coffee.
