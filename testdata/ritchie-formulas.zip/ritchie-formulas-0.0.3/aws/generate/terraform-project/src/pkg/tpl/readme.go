package tpl

const (
	Readme = `Scaffold terraform aws
	`
)
