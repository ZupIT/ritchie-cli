# Terraform aws eks

## command

```bash
rit aws add terraform-eks
```

## description

This formula receives 2 inputs (cluster name, domain name)
and adds eks module files into the project.
