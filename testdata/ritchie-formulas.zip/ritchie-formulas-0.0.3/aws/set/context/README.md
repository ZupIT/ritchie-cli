# Aws set context

## command

```bash
rit aws set context
```

## description

This formula to set the context
