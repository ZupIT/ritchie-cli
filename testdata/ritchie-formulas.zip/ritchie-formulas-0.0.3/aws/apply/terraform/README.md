# Terraform aws apply

## command

```bash
rit aws apply terraform
```
