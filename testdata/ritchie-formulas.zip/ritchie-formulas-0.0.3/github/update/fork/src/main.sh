#!/bin/bash

# shellcheck source=/dev/null
. "$PWD"/fork/fork.sh --source-only

run "$PUSH" "$SETUPSTREAM"
