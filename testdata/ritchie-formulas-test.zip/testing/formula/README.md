# Ritchie Formula

## command

```bash
rit testing formula
```

## description

description of formula
