
## testing formula

### command
```bash
$ rit testing formula
```

### description
 //TODO explain how to use this command
