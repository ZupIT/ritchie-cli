## coffee-shell

### command
```bash
$ rit scaffold generate coffee-shell
```

### local test
```bash
$ make test-local form=SC_COFFEE_SHELL
```

### description
This formula receive 4 inputs (customer name, coffee type, delivery, no delay) and builds a coffee.