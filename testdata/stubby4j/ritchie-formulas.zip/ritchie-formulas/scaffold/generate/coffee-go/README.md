## coffee-go

### command
```bash
$ rit scaffold generate coffee-go
```

### local test
```bash
$ make test-local form=SC_COFFEE_GO
```

### description
This formula receive 4 inputs (customer name, coffee type, delivery, no delay) and builds a coffee.