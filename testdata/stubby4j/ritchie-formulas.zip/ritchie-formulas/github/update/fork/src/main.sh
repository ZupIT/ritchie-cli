#!/bin/sh

. $PWD/fork/fork.sh --source-only

run $PUSH $SETUPSTREAM
