## terraform aws apply

### command
```bash
$ rit aws apply terraform
```