package tpl

const (
	Variable = `
kubernetes_cluster_name="{{.ClusterName}}"
domain_name="{{.DomainName}}"
namespace = "qa"
`
)
