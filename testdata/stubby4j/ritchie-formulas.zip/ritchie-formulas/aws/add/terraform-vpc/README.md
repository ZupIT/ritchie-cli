## terraform aws vpc

### command
```bash
$ rit aws add terraform-vpc
```

### description
This formula receives 5 inputs (region, vpc name, vpc cidr, vpc azs, customer name) and adds vpc module files into the project.