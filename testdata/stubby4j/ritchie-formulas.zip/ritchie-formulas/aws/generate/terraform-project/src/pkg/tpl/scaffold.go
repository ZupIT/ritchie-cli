package tpl

const (
	Scaffold = `scaffold=terraform-aws
	`
)
