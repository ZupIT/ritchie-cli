package tpl

const (
	Variable = `#put here your variables
	`
)
