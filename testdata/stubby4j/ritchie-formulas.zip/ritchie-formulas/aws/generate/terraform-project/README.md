## terraform aws project

### command
```bash
$ rit aws generate terraform-project
```


### description
This formula receives 2 inputs (project name, project location) and builds a terraform project with commons folders and files.