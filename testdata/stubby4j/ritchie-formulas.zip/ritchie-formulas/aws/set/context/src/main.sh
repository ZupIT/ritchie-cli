#!/bin/sh

. ./setcontext/setcontext.sh --source-only

run $CONTEXT_NAME
